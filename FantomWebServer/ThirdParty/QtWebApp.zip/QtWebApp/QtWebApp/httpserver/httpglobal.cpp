#include "httpglobal.h"

const char* getQtWebAppLibVersion()
{
    return "1.7.11";
}

